# Guardian 360 — Product & Market Blueprint

**Version:** 1.0  
**Date:** 26 August 2026  
**Status:** MASTER PRODUCT/BUSINESS REFERENCE  
**Engineering baseline:** Phase 1B-04 complete; domain schema implemented, 68/68 tests passing, production build passing, Git commit `8f8c3a4`.

## Executive Decision

Guardian 360 should not try to become another Datadog. The strongest initial opportunity is a **website/business-health monitoring platform for SMBs, digital agencies, freelancers and multi-site operators**.

Guardian should answer one business question:

> Is my website healthy, and if something is wrong, what matters, why does it matter, and what should I do next?

The current architecture already supports the central domain chain:

`Organization → Business → Website → Monitor → Issue`

with monitoring types:

`UPTIME, SSL, SEO, CONTENT, LINKS, PERFORMANCE, FORM`

## 1. Vision

Make Guardian 360 the **digital health and early-warning system for every business website**.

## 2. Mission

Continuously monitor business websites, detect problems early, explain them in plain language, prioritize business impact, and help the responsible person fix them.

## 3. Problem

Website health is fragmented across uptime, SEO, performance, SSL/domain, link, form and developer tools. SMB owners and agencies do not want to operate five different dashboards. Technical alerts also fail to answer whether an issue is serious, whether customers are affected, what should be fixed first, and who should fix it.

## 4. Solution

Guardian combines uptime, SSL, SEO, content, links, performance and critical-form monitoring into one multi-tenant SaaS platform. Its workflow is:

**Discover → Monitor → Detect → Verify → Create Issue → Prioritize → Explain → Assign → Resolve → Report**

The Issue layer is critical: Guardian should manage actionable problems, not merely collect measurements.

## 5. Target Market

**Primary beachhead:** digital agencies managing 10–500+ client websites.

Secondary segments:
- Freelance web developers
- SMBs with 1–5 business websites
- E-commerce operators
- Multi-location organizations

Agencies are strategically important because one customer can bring many monitored websites and can resell monitoring as a recurring service.

## 6. Ideal Customer Profiles

**Agency owner:** wants fewer emergency calls, automated reports and recurring maintenance revenue.

**Freelance developer:** wants automatic client-site monitoring and proof of ongoing maintenance.

**SMB owner:** wants a simple answer to whether the website is working properly.

**E-commerce operator:** needs early warning for outages, slow pages and broken conversion paths.

## 7. Competitor Analysis

### UptimeRobot
Major low-cost monitoring platform with uptime, SSL/DNS, API, keyword, ping, port, heartbeat, status pages and integrations. Its current site reports 3.4M+ users/companies and 7.57M monitors.

**Guardian response:** go beyond reachability into business health, issue intelligence, SEO/content/form context and agency workflow.

### Site24x7
Broad monitoring/observability platform covering websites, performance, RUM, synthetic transactions, SSL, DNS, servers, networks and applications.

**Guardian response:** be simpler and more business-oriented for SMBs and agencies.

### Better Stack
Modern uptime plus incident management, on-call, status pages, telemetry, error tracking, session replay and AI SRE.

**Guardian response:** do not compete on full developer observability; own website/business health.

### StatusCake
Website-focused monitoring covering uptime, page speed, domains, SSL, servers, reporting and team features.

**Guardian response:** differentiate through issue intelligence and business impact.

### Oh Dear
The closest strategic competitor. It bundles uptime, SSL, broken links, performance/Lighthouse, DNS, cron, status pages, client reporting, AI-powered checks and agency/white-label capabilities.

**Guardian response:** Guardian cannot win by simply copying the feature list. It must differentiate through AI issue intelligence, business-impact scoring, remediation guidance, workflow, integrations and distribution.

### Datadog / Dynatrace / Grafana / New Relic
Powerful enterprise observability platforms.

**Guardian response:** do not compete directly. They validate the larger monitoring/observability category while leaving room for a focused SMB/agency product.

## 8. Market Gaps

The target space is between a cheap uptime checker and an enterprise observability platform.

Potential gaps:
1. Business-impact scoring
2. Plain-English explanations
3. AI remediation plans
4. Cross-domain health score
5. Issue deduplication/fingerprinting
6. Prioritized issue queue
7. Agency portfolio management
8. White-label client reporting
9. Automated maintenance reports
10. Client-facing health dashboards
11. WordPress-aware recommendations
12. Conversion-path awareness
13. “What changed?” explanations
14. AI incident summaries
15. Smart alert suppression and verification

## 9. Guardian Positioning

**Category:** Website Health Monitoring & Intelligence

**Positioning:** Guardian 360 is the business website health platform that continuously watches websites, detects problems across uptime, performance, SEO, content, links and critical journeys, and tells users what matters and what to do next.

Guardian is not:
- a generic uptime monitor
- an enterprise observability platform
- a cybersecurity platform
- a full SEO suite
- a website builder
- a generic AI assistant

## 10. Unique Selling Proposition

> **Guardian doesn't just tell you that your website has a problem. It tells you what the problem means for the business, how urgent it is, and what to do next.**

For agencies:

> **One Guardian account can monitor an entire website portfolio and turn technical health data into client-ready reports.**

## 11. Core MVP

Monitoring:
- Uptime
- SSL
- SEO baseline
- Content
- Broken links
- Performance
- Forms / critical pages

Intelligence:
- Issue creation
- Severity
- Lifecycle status
- Fingerprint-based deduplication
- Confidence/evidence
- Impact
- Assignment
- Resolution tracking
- Alerting

Platform:
- Authentication
- Organizations/tenants
- Users and roles
- Businesses
- Websites
- Monitors
- Issues
- Dashboard
- Notifications
- Background scheduler/worker
- Basic reporting

## 12. Phase 2 Features

- AI root-cause summaries
- AI remediation plans
- AI issue grouping
- Anomaly detection
- Change correlation
- Core Web Vitals
- Lighthouse trends
- Technical SEO audits
- Sitemap/robots/indexability checks
- Checkout and booking monitoring
- Contact-form verification
- Client portals
- Automated monthly reports
- SLA reporting

## 13. AI Strategy

AI is not the gimmick; it sits on top of reliable monitoring data.

AI jobs:
1. Explain
2. Prioritize
3. Correlate
4. Recommend
5. Summarize
6. Draft remediation
7. Detect patterns
8. Reduce alert noise

Example:

**Raw alert:** HTTP 500 detected.

**Guardian intelligence:** “Critical — Checkout unavailable. Your checkout endpoint returned HTTP 500 in four consecutive checks. This may prevent customers from completing purchases. Likely impact: lost orders. Recommended action: check payment/plugin logs and recent deployments first.”

## 14. Pricing

Recommended initial structure:

| Plan | Target | Price |
|---|---|---:|
| Free | Trial/hobby | $0 |
| Starter | 1–5 sites | $19/mo |
| Growth | 10–25 sites | $49/mo |
| Pro | 50–100 sites | $99/mo |
| Agency | 250+ sites | $249–399/mo |
| Enterprise | Large portfolios | Custom |

Do not compete primarily on being the cheapest. Public pricing should remain simple.

## 15. Revenue Model

Primary: recurring SaaS subscriptions.

Secondary:
- Agency subscriptions
- White-label/reseller plans
- Premium AI usage
- Advanced reporting
- Enterprise plans
- Onboarding/implementation
- Managed monitoring services

## 16. Agency Model

Agencies should be a major distribution channel.

Agency → Clients → Businesses → Websites → Monitors → Issues

Agency features:
- portfolio monitoring
- client grouping
- team assignment
- monthly reports
- automated alerts
- health scores
- maintenance tracking
- client-facing reporting

Guardian can become infrastructure behind a recurring “Website Care & Monitoring” service.

## 17. White-Label Model

Eventually allow agencies to:
- use their logo/colors
- use a custom domain
- send reports from their brand
- hide Guardian branding
- provide restricted client access
- resell Guardian-powered monitoring

White-label should be a monetization and distribution engine, not just a cosmetic feature.

## 18. Customer Acquisition

Primary channels:
- LinkedIn
- X
- Facebook/WordPress communities
- agency communities
- developer communities
- direct outreach
- existing web-development clients
- SEO/content

Best acquisition mechanism:

**Free Website Health Scan**

URL → scan → health score → issues → “Monitor continuously” → paid plan.

## 19. 12-Month Growth Strategy

**Months 1–3:** 20–50 beta customers, 100–300 monitored websites, validate willingness to pay.

**Months 4–6:** 100+ paying customers, 1,000+ monitored websites, agency reporting, case studies.

**Months 7–9:** agency partnerships, WordPress ecosystem, reseller/referral program, free scanner.

**Months 10–12:** 5,000+ monitored websites, 300+ paying accounts, enterprise pilots and international expansion.

## 20. $1M Revenue Path

$1M ARR requires approximately **$83,333 average MRR**.

One plausible mix:
- 600 direct customers × $79 average = $47,400 MRR
- 120 agency customers × $299 average = $35,880 MRR

Total = **$83,280 MRR ≈ $999,360 ARR**, before small enterprise/add-on revenue.

The agency model matters because one agency can represent many monitored websites.

## 21. Product Roadmap

**Phase 1A:** foundation / architecture / product definition.

**Phase 1B:** database and domain foundation. Current status: **1B-04 complete**.

Next:
1. Authentication and tenant access
2. Application service layer
3. Monitor configuration
4. Scheduler
5. Worker execution engine
6. Issue engine
7. Notifications
8. Dashboard
9. Reporting
10. AI intelligence
11. Agency workflows
12. Billing
13. White-label
14. Scale/reliability

## 22. Engineering Roadmap Alignment

The current domain chain is the right foundation:

`Organization → Business → Website → Monitor → Issue`

Architecture principle:

**Monitoring generates observations.**

**The issue engine converts observations into actionable problems.**

**AI converts problems into understandable decisions.**

**Agency/white-label provides distribution.**

**Subscriptions provide recurring revenue.**

## 23. Features We Deliberately Will NOT Build Initially

Do not initially build:
- Full Datadog replacement
- Kubernetes observability
- full server observability
- SIEM
- full vulnerability scanner
- antivirus
- full Semrush/Ahrefs replacement
- full GA4 replacement
- CRM
- website builder
- project-management suite
- helpdesk
- generic AI chatbot
- massive log-management platform

## 24. Risks

**Competition:** Oh Dear is particularly close. Response: compete on intelligence, business impact and distribution.

**False positives:** use verification, confidence, deduplication and alert suppression.

**AI hallucination:** ground AI in monitoring evidence and clearly separate facts from recommendations.

**Infrastructure cost:** efficient scheduling, caching, regional workers and usage controls.

**Scope creep:** maintain a strict product boundary.

**Customer acquisition:** use free scans, agency distribution and business-impact reports.

## 25. Success Metrics

Product:
- websites monitored
- active monitors
- checks executed
- issues detected/resolved
- false-positive rate
- mean time to detect
- mean time to acknowledge
- mean time to resolve

Business:
- MRR
- ARR
- trial-to-paid conversion
- CAC
- LTV
- churn
- net revenue retention
- agency accounts
- sites per customer

Product-market-fit signals:
- customers add more sites
- agencies monitor portfolios
- customers remain after trial
- customers request additional monitoring
- reports are used with clients
- referrals increase
- customers pay for white-label features

## Strategic Product Thesis

> **Know when your website is unhealthy before your customers do.**

Guardian is not an uptime monitor.

It is a **business website health intelligence platform**.

**Monitoring = data layer.**  
**Issues = workflow layer.**  
**AI = intelligence layer.**  
**Agency/white-label = distribution layer.**  
**Recurring subscriptions = revenue layer.**

## Final Strategic Decision

There is a real market and the category is validated. The market is competitive, which is a positive signal: customers already spend money on monitoring.

Guardian should win by being:

**Simpler than observability platforms.**  
**More intelligent than uptime monitors.**  
**More business-oriented than developer monitoring tools.**  
**More agency-friendly than generic SaaS monitoring.**

The next engineering sequence is:

**Tenant access → monitor configuration → scheduler → monitoring workers → issue engine → notifications → dashboard → reporting → AI intelligence → agency/white-label → billing.**

Arena AI should not jump ahead into unrelated features.

## Current Research Sources

- UptimeRobot pricing/features — https://uptimerobot.com/pricing/
- UptimeRobot advanced features — https://uptimerobot.com/advanced-features/
- Site24x7 pricing — https://www.site24x7.com/site24x7-pricing.html
- Better Stack pricing — https://betterstack.com/pricing
- StatusCake pricing — https://www.statuscake.com/pricing/
- Oh Dear pricing/features — https://ohdear.app/pricing
- Oh Dear AI monitoring — https://ohdear.app/docs/features/ai-monitoring
- Grand View Research, Monitoring Tools Market — https://www.grandviewresearch.com/industry-analysis/monitoring-tools-market-report
- Grand View Research, Cloud Monitoring Market — https://www.grandviewresearch.com/industry-analysis/cloud-monitoring-market-report
- Fortune Business Insights, APM Market — https://www.fortunebusinessinsights.com/application-performance-monitoring-market-108515
- Gartner, Observability Platforms — https://www.gartner.com/en/documents/8114397

**Research note:** Market-size estimates vary substantially by category definition and methodology. Guardian should use monitoring/observability data as category evidence and validate its obtainable market through customer interviews, trials and paid conversions.
